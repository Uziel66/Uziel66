/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby,
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
//Uziel Juarez Perez - 184111
float Compra, Descuento;
int Color;
int main() 
{   printf ("Programa para aplicar descuetos\n");
    printf ("Uziel Juarez Perez - 184111\n");
    printf ("Ingrese el monto de la compra $");
	scanf ("%f", &Compra);

	printf ("Elija el color para el descuento\n");
	printf ("1) Amarillo \n2) Verde \n3) Rojo\n");
	scanf ("%d", &Color);

	switch (Color) {
	case 1:
		Descuento = Compra * .8;
		printf("Se aplica un 20%% de descuento. \nSu pago final es de $%.2f\n", Descuento);
		break;
	case 2:
		Descuento = Compra * .7;
		printf("Se aplica un 30%% de descuento. \nSu pago final es de $%.2f\n", Descuento);
		break;
	case 3:
	    Descuento = Compra * .5;
		printf("Se aplica un 50%% de descuento. \nSu pago final es de $%.2f\n", Descuento);
		break;
	default:
		printf("Elija un color correcto.");
	}

	return 0;
}
